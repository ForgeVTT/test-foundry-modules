export default function dependencyFunction() {
  console.log("CROSS-IMPORT-MODULE: Dependency function called.");
  return true;
}
