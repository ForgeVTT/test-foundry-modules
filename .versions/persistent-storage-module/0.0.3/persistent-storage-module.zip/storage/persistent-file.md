[foundry.packages.BaseModule](https://foundryvtt.com/api/classes/foundry.packages.BaseModule.html#defineschema)
